package com.Test;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.xml.DOMConfigurator;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.events.EventFiringWebDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.Test.Keywords;
import com.Utils.GetScreenShot;
import com.Utils.Log4j;
import com.Utils.Resources;
import com.Utils.Xls_Reader;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

import io.github.bonigarcia.wdm.WebDriverManager;

public class TestController extends Resources {

	String TestSuites = TestSuite;
	Xls_Reader s = new Xls_Reader(TestSuite);
	public static final String FIREFOX = "firefox";
	public static final String IE = "IE";
	public static final String CHROME = "chrome";

	@BeforeClass
	public void initBrowser() throws IOException {

		Initialize();
		selectBrowser(BROWSER_NAME);

	}

	/**
	 * Select the browser on which you want to execute tests
	 **/
	private void selectBrowser(String browserName) {

		switch (browserName) {

		case FIREFOX:

			firefoxProfile();
			break;

		case IE:
			ie();
			break;

		case CHROME:
			chrome();
			break;

		default:
			firefoxProfile();
			break;
		}

	}

	private void chrome() {
		// WebDriverManager.chromedriver().setup();
		ChromeOptions chromeOptions = new ChromeOptions();

		chromeOptions.setBinary("C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe");
		System.setProperty("webdriver.chrome.driver", chromeDriver);
		dr = new ChromeDriver(chromeOptions);
		dr = new ChromeDriver();
		driver = new EventFiringWebDriver(dr);

		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		driver.manage().timeouts().pageLoadTimeout(60, TimeUnit.SECONDS);
		driver.manage().timeouts().setScriptTimeout(20, TimeUnit.SECONDS);
	}

	@SuppressWarnings("deprecation")
	private void ie() {
		DesiredCapabilities returnCapabilities = DesiredCapabilities.internetExplorer();
		returnCapabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		returnCapabilities.setCapability(InternetExplorerDriver.ENABLE_PERSISTENT_HOVERING, false);
		System.setProperty("webdriver.ie.driver", IEDriver);

		dr = new InternetExplorerDriver(returnCapabilities);
		driver = new EventFiringWebDriver(dr);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		driver.manage().timeouts().pageLoadTimeout(60, TimeUnit.SECONDS);
		driver.manage().timeouts().setScriptTimeout(20, TimeUnit.SECONDS);

	}

	/**
	 * Firefox profile will help in automatic download of files
	 */
	@SuppressWarnings("deprecation")
	private void firefoxProfile() {
		System.setProperty("webdriver.gecko.driver", FirefoxDriver);

		FirefoxOptions options = new FirefoxOptions();
		options.addPreference("--log", "trace");
		DesiredCapabilities capabilities = DesiredCapabilities.firefox();
		capabilities.setCapability("moz:firefoxOptions", options);

		FirefoxProfile profile = new FirefoxProfile();
		profile.setPreference("browser.download.folderList", 1);
		profile.setPreference("browser.download.manager.showWhenStarting", false);
		profile.setPreference("browser.helperApps.neverAsk.saveToDisk",
				"application/vnd.openxmlformats-officedocument.wordprocessingml.document");

		dr = new FirefoxDriver(capabilities);
		driver = new EventFiringWebDriver(dr);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		driver.manage().timeouts().pageLoadTimeout(60, TimeUnit.SECONDS);
		driver.manage().timeouts().setScriptTimeout(20, TimeUnit.SECONDS);

	}

	@Test
	public void TestCaseController() throws Exception {
		DOMConfigurator.configure("log4j.xml");

		@SuppressWarnings("unused")
		String TCStatus = "Pass";
		ExtentTest test;
		ExtentReports extent = new ExtentReports();
		ExtentSparkReporter htmlReporter;

		// create ExtentReports and attach reporter(s)
		htmlReporter = new ExtentSparkReporter(CreateFileWithTimeStamp());
		extent.attachReporter(htmlReporter);

		// loop through the test cases
		for (int TC = 2; TC <= SuiteData.getRowCount("TestCases"); TC++) {

			TestCaseName = SuiteData.getCellData("TestCases", "TestCaseName", TC);
			String RunMode = SuiteData.getCellData("TestCases", "RunMode", TC);
			test = extent.createTest(TestCaseName, "");

			if (RunMode.equals("Y")) {
				String TSStatus = "Pass";

				System.out.println("First " + TestCaseName);

				// loop through the test steps
				System.out.println("SuiteData.getRowCount(TestCaseID)" + SuiteData.getRowCount(TestCaseName));

				for (int TS = 2; TS <= SuiteData.getRowCount(TestCaseName); TS++) {
					testcase_ID = SuiteData.getCellData(TestCaseName, "Test Case ID", TS);
					keyword = SuiteData.getCellData(TestCaseName, "Keyword", TS);
					webElement = SuiteData.getCellData(TestCaseName, "WebElement", TS);
					ProceedOnFail = SuiteData.getCellData(TestCaseName, "ProceedOnFail", TS);
					testStepID = SuiteData.getCellData(TestCaseName, "TestStepID", TS);
					Description = SuiteData.getCellData(TestCaseName, "Description", TS);
					TestDataField = SuiteData.getCellData(TestCaseName, "TestDataField", TS);
					TestData = TestStepData.GetTestData("MasterTestData", testcase_ID, TestDataField, "Testdata");
					Log4j.startTestCase(TestCaseName, keyword, webElement, TestData);
					Method method = Keywords.class.getMethod(keyword);
					TSStatus = (String) method.invoke(method);

					if (TSStatus.contains("Failed")) {
						// take the screenshot
						String filename = TestCaseName + testStepID + "[" + TestData + "]";
						TCStatus = TSStatus;
						Log4j.error(TestCaseName);
						String screenShot = GetScreenShot.capture(driver, filename);
						test.fail(
								"Failed Step at--- " + testStepID + "----" + keyword + "----" + Description + "---"
										+ TestData + "",
								MediaEntityBuilder
										.createScreenCaptureFromPath(screenShot,
												testStepID + "--- " + keyword + "---" + Log4j.error(TestCaseName))
										.build());

					} else {
						test.log(Status.PASS, "--" + testStepID + "--" + Description + "-- " + TestDataField + "------"
								+ TestData + "");
					}

					if (ProceedOnFail.equals("N")) {
						break;
					}

				}
			}
		}

		extent.flush();

	}

	@AfterTest
	public void quitBrowser() {
		System.out.println("In quitBrowser---------------------------");
		// driver.quit();
	}

}
